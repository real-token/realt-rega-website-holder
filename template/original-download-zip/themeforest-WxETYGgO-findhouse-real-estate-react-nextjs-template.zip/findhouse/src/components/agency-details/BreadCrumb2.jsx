import BreadCrumb from "../common/BreadCrumb";

const BreadCrumbBlog = () => {
  return (
    <div className="breadcrumb_content style2">
      <BreadCrumb title="Agency Single" />
      <h2 className="breadcrumb_title">Agency Single</h2>
    </div>
  );
};

export default BreadCrumbBlog;
