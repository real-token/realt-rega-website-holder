const Filtering = () => {
  return (
    <select className="selectpicker show-tick form-select c_select">
      <option>Featured First</option>
      <option>Recent</option>
      <option>Old Review</option>
    </select>
  );
};

export default Filtering;
