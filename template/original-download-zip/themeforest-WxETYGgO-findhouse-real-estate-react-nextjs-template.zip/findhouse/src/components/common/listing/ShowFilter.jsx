const ShowFilter = () => {
  return (
    <div id="main2" data-bs-toggle="offcanvas" data-bs-target="#sidebarListing">
      <span
        id="open2"
        className="flaticon-filter-results-button filter_open_btn style2"
      >
        Show Filter
      </span>
    </div>
  );
};

export default ShowFilter;
