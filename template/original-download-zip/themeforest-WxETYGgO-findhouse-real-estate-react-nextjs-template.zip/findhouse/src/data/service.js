module.exports = [
  {
    id: 1,
    img: "/assets/images/service/1.jpg",
    title: "Redfin Ranks the Most Competitive Neighborhoods of 2020",
  },
  {
    id: 2,
    img: "/assets/images/service/2.jpg",
    title: "Why We Should All Support Clear Cooperation",
  },
  {
    id: 3,
    img: "/assets/images/service/3.jpg",
    title: "Redfin Ranks the Most Competitive Neighborhoods of 2020",
  },
  {
    id: 4,
    img: "/assets/images/service/4.jpg",
    title: "12 Walkable Cities Where You Can Live Affordably",
  },
  {
    id: 5,
    img: "/assets/images/service/5.jpg",
    title: "Redfin Unveils the Best Canadian Cities for Biking",
  },
  {
    id: 6,
    img: "/assets/images/service/6.jpg",
    title: "You Can Buy The Piano Teacher’s Home from Groundhog Day",
  },
  {
    id: 7,
    img: "/assets/images/service/7.jpg",
    title: "Housing Markets That Changed the Most This Decade",
  },
  {
    id: 8,
    img: "/assets/images/service/8.jpg",
    title: "Redfin Ranks the Most Competitive Neighborhoods of 2020",
  },
  {
    id: 9,
    img: "/assets/images/service/9.jpg",
    title: "12 Walkable Cities Where You Can Live Affordably",
  },
];
