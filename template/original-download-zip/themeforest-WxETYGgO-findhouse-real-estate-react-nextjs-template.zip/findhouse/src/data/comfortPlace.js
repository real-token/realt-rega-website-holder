module.exports = [
  {
    id: 1,
    bgImg: "/assets/images/service/4.jpg",
    icon: "flaticon-house",
    name: "Miami",
    number: "07",
  },
  {
    id: 2,
    bgImg: "/assets/images/service/5.jpg",
    icon: "flaticon-house-1",
    name: "Family House",
    number: "07",
  },
  {
    id: 3,
    bgImg: "/assets/images/service/3.jpg",
    icon: "flaticon-house-2",
    name: "Town House",
    number: "07",
  },
  {
    id: 4,
    bgImg: "/assets/images/service/1.jpg",
    icon: "flaticon-building",
    name: "Apartment",
    number: "07",
  },
];
