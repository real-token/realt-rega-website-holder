module.exports = [
  { id: 1, img: "/assets/images/property/fp1.jpg" },
  { id: 2, img: "/assets/images/property/fp2.jpg" },
  { id: 3, img: "/assets/images/property/fp3.jpg" },
  { id: 4, img: "/assets/images/property/fp4.jpg" },
  { id: 5, img: "/assets/images/property/fp5.jpg" },
  { id: 6, img: "/assets/images/property/fp6.jpg" },
  { id: 7, img: "/assets/images/property/fp7.jpg" },
  { id: 8, img: "/assets/images/property/fp8.jpg" },
  { id: 9, img: "/assets/images/property/fp9.jpg" },
];
