module.exports = [
  {
    id: 1,
    title: "Modern Villa",
    icon: "flaticon-house",
    text: `Aliquam dictum elit vitae mauris facilisis, at dictum urna.`,
  },
  {
    id: 2,
    title: "Family House",
    icon: "flaticon-house-1",
    text: `Aliquam dictum elit vitae mauris facilisis, at dictum urna.`,
  },
  {
    id: 3,
    title: "Town House",
    icon: "flaticon-house-2",
    text: `Aliquam dictum elit vitae mauris facilisis, at dictum urna.`,
  },
  {
    id: 4,
    title: "Apartment",
    icon: "flaticon-building",
    text: `Aliquam dictum elit vitae mauris facilisis, at dictum urna.`,
  },
];
